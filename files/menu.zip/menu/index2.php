<!DOCTYPE HTML PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html lang="en-US">
<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Elegant Drop Menu with CSS Only</title>
<link rel="stylesheet" href="style.css" type="text/css" media="screen">
<!--[if IE 6]>
<style type="text/css">
#vertical-navigation li:hover ul li a,
#vertical-navigation ul li a
{
	line-height: 50%;
}

#vertical-navigation ul
{
	top: 2.5em;
}
</style>
<![endif]--> 

</head>
<body>
<?php

$username = "root";
$password = "root";
$database = "menu";
$server = "127.0.0.1";
$dbhandle=mysql_connect($server,$username,$password);
$dbfound=mysql_select_db($database,$dbhandle);

$sql="select * from nav";
$result=mysql_query($sql);
?>
<div id="content">
  <ul id="vertical-navigation">
    <li class=""> <a href="#">HOME</a>
    <ul>
    <?php
    while($row=mysql_fetch_assoc($result))
{
			$var=explode("*",$row["Home"]);
			echo '<li class=""><a href="'.$var[1].'"target="_blank">'.$var["0"].'</a></li>';
}
?>
    
    
    
    </ul>
     </li>
    <li class=""> <a href="#">ARCHIVE</a>
      <ul>
         <?php
		
		 $result=mysql_query($sql);
    while($row=mysql_fetch_assoc($result))
{
			echo '<li class=""><a href="#">'.$row["Archive"].'</a></li>';
}
?>
      </ul>
    </li>
    
    <!-- Begin parent item -->
    <li class=""> <a href="#">RSS FEED</a>
      
      <!-- Begin Child Items Group-->
      <ul>
      
        <!-- Begin Child Item-->
        <li class=""> <a href="#">Child Item 1</a> </li>
        <li class=""> <a href="#">Child Item 2</a> </li>
        
      </ul>
      <!-- End Child Items Group-->
      
    </li>
    <!-- End parent item -->
    
    <li class=""> <a href="#">RANDOM</a> </li>
      <li class=""> <a href="#">CONTACT US
      
  </a> </li>
  </ul>
  
 </div>
</body>
</html>