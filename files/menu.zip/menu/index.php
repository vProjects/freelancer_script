<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<link href="style.css" rel="stylesheet" type="text/css"  />
</head>

<body>
<?php

$username = "root";
$password = "root";
$database = "menu";
$server = "127.0.0.1";
$dbhandle=mysql_connect($server,$username,$password);
$dbfound=mysql_select_db($database,$dbhandle);

$sql="select * from nav";
$result=mysql_query($sql);
echo '<form action="out.php" method="get" >';
echo '<table border="1px">';

$i=1;

while($row=mysql_fetch_assoc($result))
{
	      echo '<tr>
		         <td> <input type="text"  value='.$row["id"].'></td>
		  		<td> <input type="text" name='.$i."a".'  value='.$row["Home"].'></td>
				<td> <input type="text" name='.$i."b".'  value='.$row["Archive"].'></td>
				<td><input type="text" name='.$i."c".'  value= '.$row["RSS_feed"].'></td>
				<td> <input type="text" name='.$i."d".'  value='.$row["Random"].'></td>
				<td><input type="text" name='.$i."e".' value= '.$row["Contact"].'></td>
		  	</tr>';
			$i++;
			 
	 
}
echo '</table>';
?>
<input type="submit" value="submit" name="input"  />

<input type="submit" value="ROW" name="input1"  />

<input type="text"  name="input2"  />

</form>



</body>
</html>