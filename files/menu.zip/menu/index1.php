<?php
$str = "Hello world. * It's a beautiful day.";
$var=explode("*",$str);
echo $var['0'];
?>