-- phpMyAdmin SQL Dump
-- version 3.5.2.2
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 17, 2013 at 01:33 PM
-- Server version: 5.5.27
-- PHP Version: 5.4.7

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `menu`
--

-- --------------------------------------------------------

--
-- Table structure for table `nav`
--

CREATE TABLE IF NOT EXISTS `nav` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Home` varchar(50) NOT NULL,
  `Archive` varchar(50) NOT NULL,
  `RSS_feed` varchar(50) NOT NULL,
  `Random` varchar(50) NOT NULL,
  `Contact` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `nav`
--

INSERT INTO `nav` (`id`, `Home`, `Archive`, `RSS_feed`, `Random`, `Contact`) VALUES
(1, 'GDSF', 'HelloNBNN', 'How', 'How', 'How'),
(2, 'GDSF', 'HelloMNM', 'C', 'C', 'HowICJKLSDN'),
(3, 'GDSF', 'Helhjhjhj', 'bnnn', 'bnnn', 'bbhnmnm'),
(4, 'BBBBNB', 'Hello', 'ffgf', 'How', 'hgg');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
