<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php


$username = "root";
$password = "root";
$database = "menu";
$server = "127.0.0.1";
$ip=$_GET['input'];
$ip1=$_GET['input1'];
$ip2=$_GET['input2'];
$dbhandle=mysql_connect($server,$username,$password);
$dbfound=mysql_select_db($database,$dbhandle);

//print_r($GLOBALS[_GET]);

$c='select id from nav order by id desc';
$count=mysql_query($c);
$result=mysql_fetch_assoc($count);
$v=$result['id'];

if(isset($ip))
{

	$sql="update nav set Home='".$_GET[$ip2.'a']."' ,Archive='".$_GET[$ip2.'b']."' ,RSS_feed='".$_GET[$ip2.'c']."',Random='".$_GET[$ip2.'d']."',Contact='".$_GET[$ip2.'e']."'WHERE id=$ip2";
	echo $sql;
	mysql_query($sql);
	header("location:index.php");
	
}

else if(isset($ip1))
{
	echo 'sadfasdf';
	$sql1="INSERT INTO nav( `Home`, `Archive`, `RSS_feed`, `Random`, `Contact`) VALUES ('','','','','')";
	mysql_query($sql1);
	header("location:index.php");
}
echo'welcome';


?>
</body>
</html>